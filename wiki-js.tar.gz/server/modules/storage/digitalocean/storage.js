const S3CompatibleStorage = require('../s3/common')

module.exports = new S3CompatibleStorage('Digitalocean')
